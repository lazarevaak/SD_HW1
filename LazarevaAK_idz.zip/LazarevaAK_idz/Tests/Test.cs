﻿using System;
using System.Linq;
using FinanceLib.DomainModels;
using FinanceLib.Facades;
using FinanceLib.Factories;
using FinanceLib.Interfaces;
using Xunit;

namespace Tests
{
    // Тесты для класса DomainFactory
    public class DomainFactoryTests
    {
        private readonly DomainFactory _factory = new DomainFactory();

        [Fact]
        public void CreateBankAccount_ValidParameters_ShouldReturnBankAccount()
        {
            // Arrange
            string name = "Savings Account";
            decimal initialBalance = 500m;

            // Act
            var account = _factory.CreateBankAccount(name, initialBalance);

            // Assert
            Assert.NotNull(account);
            Assert.Equal(name, account.Name);
            Assert.Equal(initialBalance, account.Balance);
            Assert.NotEqual(Guid.Empty, account.Id);
        }

        [Fact]
        public void CreateCategory_ValidParameters_ShouldReturnCategory()
        {
            // Arrange
            string name = "Salary";
            CategoryType type = CategoryType.Income;

            // Act
            var category = _factory.CreateCategory(type, name);

            // Assert
            Assert.NotNull(category);
            Assert.Equal(name, category.Name);
            Assert.Equal(type, category.Type);
            Assert.NotEqual(Guid.Empty, category.Id);
        }

        [Fact]
        public void CreateOperation_ValidParameters_ShouldReturnOperation()
        {
            // Arrange
            OperationType type = OperationType.Income;
            var bankAccountId = Guid.NewGuid();
            decimal amount = 100m;
            var date = DateTime.Now.AddDays(-1);
            var categoryId = Guid.NewGuid();
            string description = "Test operation";

            // Act
            var operation = _factory.CreateOperation(type, bankAccountId, amount, date, categoryId, description);

            // Assert
            Assert.NotNull(operation);
            Assert.Equal(type, operation.Type);
            Assert.Equal(bankAccountId, operation.BankAccountId);
            Assert.Equal(amount, operation.Amount);
            Assert.Equal(date, operation.Date);
            Assert.Equal(description, operation.Description);
            Assert.Equal(categoryId, operation.CategoryId);
            Assert.NotEqual(Guid.Empty, operation.Id);
        }
    }

    // Тесты для фасада банковских счетов
    public class BankAccountFacadeTests
    {
        private readonly DomainFactory _factory = new DomainFactory();
        private readonly BankAccountFacade _facade;

        public BankAccountFacadeTests()
        {
            _facade = new BankAccountFacade(_factory);
        }

        [Fact]
        public void Create_ShouldAddBankAccount()
        {
            // Arrange
            string name = "Checking Account";
            decimal initialBalance = 1000m;

            // Act
            var account = _facade.Create(name, initialBalance);

            // Assert
            Assert.NotNull(account);
            Assert.Equal(name, account.Name);
            Assert.Equal(initialBalance, account.Balance);
            var retrieved = _facade.GetById(account.Id);
            Assert.Equal(account, retrieved);
        }

        [Fact]
        public void Update_ShouldChangeBankAccountName()
        {
            // Arrange
            var account = _facade.Create("Old Name", 100m);
            string newName = "New Name";

            // Act
            _facade.Update(account.Id, newName);

            // Assert
            var updated = _facade.GetById(account.Id);
            Assert.Equal(newName, updated.Name);
        }

        [Fact]
        public void Delete_ShouldRemoveBankAccount()
        {
            // Arrange
            var account = _facade.Create("Temporary Account", 200m);

            // Act
            _facade.Delete(account.Id);

            // Assert
            Assert.Throws<KeyNotFoundException>(() => _facade.GetById(account.Id));
        }

        [Fact]
        public void GetAll_ShouldReturnAllAccounts()
        {
            // Arrange
            _facade.Create("Account1", 100m);
            _facade.Create("Account2", 200m);

            // Act
            var accounts = _facade.GetAll();

            // Assert
            Assert.True(accounts.Count() >= 2);
        }
    }

    // Тесты для фасада категорий
    public class CategoryFacadeTests
    {
        private readonly DomainFactory _factory = new DomainFactory();
        private readonly CategoryFacade _facade;

        public CategoryFacadeTests()
        {
            _facade = new CategoryFacade(_factory);
        }

        [Fact]
        public void Create_ShouldAddCategory()
        {
            // Arrange
            string name = "Groceries";
            CategoryType type = CategoryType.Expense;

            // Act
            var category = _facade.Create(type, name);

            // Assert
            Assert.NotNull(category);
            Assert.Equal(name, category.Name);
            Assert.Equal(type, category.Type);
            var retrieved = _facade.GetById(category.Id);
            Assert.Equal(category, retrieved);
        }

        [Fact]
        public void Update_ShouldChangeCategoryName()
        {
            // Arrange
            var category = _facade.Create(CategoryType.Income, "Old Category");
            string newName = "Updated Category";

            // Act
            _facade.Update(category.Id, newName);

            // Assert
            var updated = _facade.GetById(category.Id);
            Assert.Equal(newName, updated.Name);
        }

        [Fact]
        public void Delete_ShouldRemoveCategory()
        {
            // Arrange
            var category = _facade.Create(CategoryType.Expense, "Temporary Category");

            // Act
            _facade.Delete(category.Id);

            // Assert
            Assert.Throws<KeyNotFoundException>(() => _facade.GetById(category.Id));
        }

        [Fact]
        public void GetAll_ShouldReturnAllCategories()
        {
            // Arrange
            _facade.Create(CategoryType.Income, "Category1");
            _facade.Create(CategoryType.Expense, "Category2");

            // Act
            var categories = _facade.GetAll();

            // Assert
            Assert.True(categories.Count() >= 2);
        }

        [Fact]
        public void GetByType_ShouldReturnOnlyCategoriesOfGivenType()
        {
            // Arrange
            var incomeCategory = _facade.Create(CategoryType.Income, "Salary");
            _facade.Create(CategoryType.Expense, "Food");

            // Act
            var incomeCategories = _facade.GetByType(CategoryType.Income);

            // Assert
            Assert.Contains(incomeCategory, incomeCategories);
            Assert.All(incomeCategories, c => Assert.Equal(CategoryType.Income, c.Type));
        }
    }

    // Тесты для фасада операций
    public class OperationFacadeTests
    {
        private readonly DomainFactory _factory = new DomainFactory();
        private readonly OperationFacade _facade;

        public OperationFacadeTests()
        {
            _facade = new OperationFacade(_factory);
        }

        [Fact]
        public void Create_ShouldAddOperation()
        {
            // Arrange
            OperationType type = OperationType.Income;
            var bankAccountId = Guid.NewGuid();
            decimal amount = 150m;
            var categoryId = Guid.NewGuid();
            string description = "Test operation";

            // Act
            var createdOperation = _facade.Create(type, bankAccountId, amount, categoryId, description);

            // Assert
            Assert.NotNull(createdOperation);
            Assert.Equal(type, createdOperation.Type);
            Assert.Equal(bankAccountId, createdOperation.BankAccountId);
            Assert.Equal(amount, createdOperation.Amount);
            Assert.Equal(description, createdOperation.Description);
            Assert.Equal(categoryId, createdOperation.CategoryId);
            Assert.NotEqual(Guid.Empty, createdOperation.Id);
        }

        [Fact]
        public void Delete_ShouldRemoveOperation()
        {
            // Arrange
            var op = _facade.Create(OperationType.Expense, Guid.NewGuid(), 50m, Guid.NewGuid(), "Operation to delete");

            // Act
            _facade.Delete(op.Id);

            // Assert
            Assert.Throws<KeyNotFoundException>(() => _facade.GetById(op.Id));
        }

        [Fact]
        public void GetAll_ShouldReturnAllOperations()
        {
            // Arrange
            _facade.Create(OperationType.Income, Guid.NewGuid(), 100m, Guid.NewGuid(), "Op1");
            _facade.Create(OperationType.Expense, Guid.NewGuid(), 200m, Guid.NewGuid(), "Op2");

            // Act
            var operations = _facade.GetAll();

            // Assert
            Assert.True(operations.Count() >= 2);
        }

        [Fact]
        public void GetByAccount_ShouldReturnOperationsForGivenAccount()
        {
            // Arrange
            var accountId = Guid.NewGuid();
            _facade.Create(OperationType.Income, accountId, 100m, Guid.NewGuid(), "Op Account 1");
            _facade.Create(OperationType.Expense, accountId, 50m, Guid.NewGuid(), "Op Account 2");
            _facade.Create(OperationType.Income, Guid.NewGuid(), 150m, Guid.NewGuid(), "Other Account");

            // Act
            var operations = _facade.GetByAccount(accountId);

            // Assert
            Assert.True(operations.All(o => o.BankAccountId == accountId));
        }

        [Fact]
        public void GetByCategory_ShouldReturnOperationsForGivenCategory()
        {
            // Arrange
            var categoryId = Guid.NewGuid();
            _facade.Create(OperationType.Income, Guid.NewGuid(), 120m, categoryId, "Op Category 1");
            _facade.Create(OperationType.Expense, Guid.NewGuid(), 80m, categoryId, "Op Category 2");
            _facade.Create(OperationType.Income, Guid.NewGuid(), 90m, Guid.NewGuid(), "Other Category");

            // Act
            var operations = _facade.GetByCategory(categoryId);

            // Assert
            Assert.True(operations.All(o => o.CategoryId == categoryId));
        }

        [Fact]
        public void GetByDateRange_ShouldReturnOperationsWithinDateRange()
        {
            // Arrange
            DateTime now = DateTime.Now;
            var op1 = _facade.Create(OperationType.Income, Guid.NewGuid(), 100m, Guid.NewGuid(), "Op Date 1");
            System.Threading.Thread.Sleep(10); // гарантируем разницу во времени
            var op2 = _facade.Create(OperationType.Income, Guid.NewGuid(), 200m, Guid.NewGuid(), "Op Date 2");

            // Act
            var start = now.AddMilliseconds(-1);
            var end = DateTime.Now.AddMilliseconds(1);
            var operations = _facade.GetByDateRange(start, end);

            // Assert
            Assert.Contains(op1, operations);
            Assert.Contains(op2, operations);
        }
    }
}
