﻿namespace FinanceLib.DomainModels
{
    /// <summary>
    /// Класс для хранения сырых данных, которые будут использованы при импорте/экспорте.
    /// </summary>
    public class ImportExportData
    {
        public string RawData { get; set; }

        // Конструктор, чтобы создать объект с исходными данными
        public ImportExportData(string rawData)
        {
            if (string.IsNullOrEmpty(rawData))
                throw new ArgumentException("Данные не могут быть пустыми.", nameof(rawData));

            RawData = rawData;
        }
    }
}
