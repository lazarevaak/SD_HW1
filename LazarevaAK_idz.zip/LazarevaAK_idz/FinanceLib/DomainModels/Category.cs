﻿using System;
using System.Text.Json.Serialization;
using FinanceLib.Interfaces;

namespace FinanceLib.DomainModels
{
    public enum CategoryType
    {
        Income,
        Expense
    }

    public class Category : IEntity
    {
        public Guid Id { get; private set; }
        public CategoryType Type { get; private set; }
        public string Name { get; private set; }

        public Guid GetId() => Id;

        public Category(string name, CategoryType type)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Название категории не может быть пустым.", nameof(name));

            Id = Guid.NewGuid();
            Name = name;
            Type = type;
        }

        [JsonConstructor]
        public Category(Guid id, CategoryType type, string name)
            : this(name, type)
        {
            if (id == Guid.Empty)
                throw new ArgumentException("ID категории не может быть пустым.", nameof(id));
            Id = id;
        }

        public void ChangeName(string newName)
        {
            if (string.IsNullOrWhiteSpace(newName))
                throw new ArgumentException("Новое название категории не может быть пустым.", nameof(newName));

            Name = newName;
        }

        public void Accept(IExportVisitor visitor)
        {
            visitor.VisitCategory(this);
        }
    }
}
