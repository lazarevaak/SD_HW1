﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using FinanceLib.Interfaces;

namespace FinanceLib.DomainModels
{
    public class BankAccount : IEntity
    {
        public Guid Id { get; private set; }
        public string Name { get; private set; }
        public decimal Balance { get; private set; }

        public Guid GetId() => Id;

        public BankAccount(string name, decimal initialBalance = 0)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Название счета не может быть пустым.", nameof(name));
            if (initialBalance < 0)
                throw new ArgumentException("Начальный баланс не может быть отрицательным.", nameof(initialBalance));

            Id = Guid.NewGuid();
            Name = name;
            Balance = initialBalance;
        }

        [JsonConstructor]
        public BankAccount(Guid id, string name, decimal balance)
            : this(name, balance)
        {
            if (id == Guid.Empty)
                throw new ArgumentException("ID счета не может быть пустым.", nameof(id));
            Id = id;
        }

        public void AdjustBalance(decimal amount)
        {
            if (Balance + amount < 0)
                throw new InvalidOperationException("Баланс не может стать отрицательным.");

            Balance += amount;
        }

        public void RecalculateBalance(IEnumerable<Operation> operations)
        {
            if (operations == null)
                throw new ArgumentNullException(nameof(operations));

            decimal newBalance = 0;
            foreach (var op in operations)
            {
                if (op.BankAccountId == this.Id)
                {
                    newBalance += op.Type == OperationType.Income ? op.Amount : -op.Amount;
                }
            }

            if (newBalance != Balance)
            {
                Console.WriteLine($"Обнаружено несоответствие баланса. Старый баланс: {Balance}, новый баланс: {newBalance}. Баланс обновлен.");
                Balance = newBalance;
            }
            else
            {
                Console.WriteLine("Баланс корректен.");
            }
        }

        public void ChangeName(string newName)
        {
            if (string.IsNullOrWhiteSpace(newName))
                throw new ArgumentException("Новое название счета не может быть пустым.", nameof(newName));

            Name = newName;
        }

        public void Accept(IExportVisitor visitor)
        {
            visitor.VisitBankAccount(this);
        }

    }
}
