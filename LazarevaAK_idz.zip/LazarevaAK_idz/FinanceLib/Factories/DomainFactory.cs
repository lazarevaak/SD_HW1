﻿using System;
using FinanceLib.DomainModels;
using FinanceLib.Interfaces;

namespace FinanceLib.Factories
{
    public class DomainFactory : IDomainFactory
    {

        public BankAccount CreateBankAccount(string name, decimal initialBalance = 0)
        {
            return new BankAccount(name, initialBalance);
        }

        public Category CreateCategory(CategoryType type, string name)
        {
            return new Category(name, type);
        }

        public Operation CreateOperation(OperationType type, Guid bankAccountId, decimal amount, DateTime date, Guid categoryId, string description = " ")
        {
            return new Operation(type, bankAccountId, amount, date, description, categoryId);
        }
    }
}
