﻿using System;
using FinanceLib.Interfaces;

namespace FinanceLib.Commands
{
    public class CreateBankAccountCommand : ICommand
    {
        private readonly IBankAccountFacade _bankAccountFacade;
        private readonly string _name;
        private readonly decimal _initialBalance;

        public CreateBankAccountCommand(IBankAccountFacade bankAccountFacade, string name, decimal initialBalance)
        {
            _bankAccountFacade = bankAccountFacade;
            _name = name;
            _initialBalance = initialBalance;
        }

        public void Execute()
        {
            _bankAccountFacade.Create(_name, _initialBalance);
            Console.WriteLine($"Создан новый банковский счет: {_name} с балансом {_initialBalance}");
        }
    }
}
