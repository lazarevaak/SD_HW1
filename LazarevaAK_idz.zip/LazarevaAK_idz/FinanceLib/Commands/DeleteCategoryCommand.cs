﻿using System;
using FinanceLib.Interfaces;

namespace FinanceLib.Commands
{
    public class DeleteCategoryCommand : ICommand
    {
        private readonly ICategoryFacade _categoryFacade;
        private readonly Guid _categoryId;

        public DeleteCategoryCommand(ICategoryFacade categoryFacade, Guid categoryId)
        {
            _categoryFacade = categoryFacade;
            _categoryId = categoryId;
        }

        public void Execute()
        {
            _categoryFacade.Delete(_categoryId);
            Console.WriteLine($"Категория с ID {_categoryId} удалена.");
        }
    }
}
