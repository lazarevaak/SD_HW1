﻿using System;
using FinanceLib.Interfaces;

namespace FinanceLib.Commands
{
    public class UpdateCategoryCommand : ICommand
    {
        private readonly ICategoryFacade _categoryFacade;
        private readonly Guid _categoryId;
        private readonly string _newName;

        public UpdateCategoryCommand(ICategoryFacade categoryFacade, Guid categoryId, string newName)
        {
            _categoryFacade = categoryFacade;
            _categoryId = categoryId;
            _newName = newName;
        }

        public void Execute()
        {
            _categoryFacade.Update(_categoryId, _newName);
            Console.WriteLine($"Категория с ID {_categoryId} обновлена на {_newName}");
        }
    }
}
