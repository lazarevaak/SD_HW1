﻿using System;
using FinanceLib.DomainModels;
using FinanceLib.Interfaces;

namespace FinanceLib.Commands
{
    public class CreateOperationCommand : ICommand
    {
        private readonly IOperationFacade _operationFacade;
        private readonly OperationType _type;
        private readonly Guid _bankAccountId;
        private readonly decimal _amount;
        private readonly Guid _categoryId;
        private readonly string _description;

        public CreateOperationCommand(IOperationFacade operationFacade, OperationType type, Guid bankAccountId, decimal amount, Guid categoryId, string description = "")
        {
            _operationFacade = operationFacade;
            _type = type;
            _bankAccountId = bankAccountId;
            _amount = amount;
            _categoryId = categoryId;
            _description = description;
        }

        public void Execute()
        {
            var operation = _operationFacade.Create(_type, _bankAccountId, _amount, _categoryId, _description);
            Console.WriteLine($"Операция создана: {operation.Type} на сумму {operation.Amount}.");
        }
    }
}
