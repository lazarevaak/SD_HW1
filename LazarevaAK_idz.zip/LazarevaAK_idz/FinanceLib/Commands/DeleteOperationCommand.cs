﻿using System;
using FinanceLib.Interfaces;

namespace FinanceLib.Commands
{
    public class DeleteOperationCommand : ICommand
    {
        private readonly IOperationFacade _operationFacade;
        private readonly Guid _operationId;

        public DeleteOperationCommand(IOperationFacade operationFacade, Guid operationId)
        {
            _operationFacade = operationFacade;
            _operationId = operationId;
        }

        public void Execute()
        {
            _operationFacade.Delete(_operationId);
            Console.WriteLine($"Операция с ID {_operationId} удалена.");
        }
    }
}
