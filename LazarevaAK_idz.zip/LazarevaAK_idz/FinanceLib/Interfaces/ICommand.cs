﻿using System;

namespace FinanceLib.Interfaces
{
    public interface ICommand
    {
        void Execute();
    }
}
