﻿using FinanceLib.DomainModels;

namespace FinanceLib.Interfaces
{
    public interface IExportVisitor
    {
        void VisitBankAccount(BankAccount account);
        void VisitCategory(Category category);
        void VisitOperation(Operation operation);

        string GetCsv();
        string GetJson();
        string GetYaml();
    }
}
