﻿using System;
namespace FinanceLib.Interfaces
{
    public interface IEntity
    {
        Guid GetId();
    }
}

