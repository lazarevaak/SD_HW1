﻿using System;
using FinanceLib.DomainModels;

namespace FinanceLib.Interfaces
{
    public interface IDomainFactory
    {
        BankAccount CreateBankAccount(string name, decimal initialBalance = 0);
        Category CreateCategory(CategoryType type, string name);
        Operation CreateOperation(OperationType type, Guid bankAccountId, decimal amount, DateTime date, Guid categoryId, string description = " ");
    }
}
