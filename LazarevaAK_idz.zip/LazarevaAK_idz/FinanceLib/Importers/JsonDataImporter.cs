﻿using System;
using System.Text.Json;
using System.IO;
using System.Collections.Generic;
using FinanceLib.DomainModels;

namespace FinanceLib.Importers
{
    public class JsonDataImporter : DataImporter<JsonData>
    {
        public JsonData ImportDataFromFile(string filePath)
        {
            ImportDataFromString(filePath);
            return ParseData(File.ReadAllText(filePath)); // Возвращаем обработанные данные
        }

        // Метод для импорта данных из строки
        public void Import(string rawData)
        {
            // Используем родительский метод для импорта данных
            ImportDataFromString(rawData);
        }

        protected override JsonData ParseData(string fileContent)
        {
            try
            {
                return JsonSerializer.Deserialize<JsonData>(fileContent);
            }
            catch (JsonException ex)
            {
                throw new Exception("Ошибка при парсинге JSON: " + ex.Message, ex);
            }
        }

        protected override void ProcessData(JsonData data)
        {
            Console.WriteLine("Обработка данных JSON...");
        }
    }

    public class JsonData
    {
        public List<BankAccount> Accounts { get; set; }
        public List<Category> Categories { get; set; }
        public List<Operation> Operations { get; set; }
    }
}
