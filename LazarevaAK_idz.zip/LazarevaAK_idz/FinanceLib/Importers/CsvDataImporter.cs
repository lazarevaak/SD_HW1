﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using FinanceLib.DomainModels;

namespace FinanceLib.Importers
{
    public class CsvDataImporter : DataImporter<CsvData>
    {
        public CsvData ImportDataFromFile(string filePath)
        {
            // Вызываем ImportData и возвращаем результат
            ImportDataFromFile(filePath);
            return ParseData(File.ReadAllText(filePath)); // Возвращаем обработанные данные
        }
        
        // Метод для импорта данных из строки
        public CsvData ImportDataFromString(string rawData)
        {
            ImportDataFromFile(rawData);
            return ParseData(rawData); // Возвращаем обработанные данные
        }

        protected override CsvData ParseData(string fileContent)
        {
            var exportData = new CsvData
            {
                Accounts = new List<BankAccount>(),
                Categories = new List<Category>(),
                Operations = new List<Operation>()
            };

            var lines = fileContent.Split(new[] { "\r\n", "\n" }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var line in lines.Skip(1))
            {
                if (string.IsNullOrWhiteSpace(line))
                    continue;

                var cells = SplitCsvLine(line);
                if (cells.Length == 0)
                    continue;

                try
                {
                    if (cells.Length == 3 && decimal.TryParse(cells[2].Trim(), NumberStyles.Any, CultureInfo.GetCultureInfo("ru-RU"), out _))
                    {
                        var id = Guid.Parse(cells[0].Trim());
                        var name = cells[1].Trim();
                        var balance = decimal.Parse(cells[2].Trim(), CultureInfo.GetCultureInfo("ru-RU"));
                        exportData.Accounts.Add(new BankAccount(id, name, balance));
                    }
                    else if (cells.Length == 3 && Enum.TryParse<CategoryType>(cells[1].Trim(), true, out var categoryType))
                    {
                        var id = Guid.Parse(cells[0].Trim());
                        var name = cells[2].Trim();
                        exportData.Categories.Add(new Category(id, categoryType, name));
                    }
                    else if (cells.Length >= 7)
                    {
                        var id = Guid.Parse(cells[0].Trim());
                        var type = (OperationType)Enum.Parse(typeof(OperationType), cells[1].Trim(), true);
                        var bankAccountId = Guid.Parse(cells[2].Trim());
                        var amount = decimal.Parse(cells[3].Trim(), CultureInfo.GetCultureInfo("ru-RU"));
                        var date = DateTime.ParseExact(cells[4].Trim(), "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                        var description = cells[5].Trim();
                        var categoryId = Guid.Parse(cells[6].Trim());
                        exportData.Operations.Add(new Operation(id, type, bankAccountId, amount, date, description, categoryId));
                    }
                }
                catch (Exception ex)
                {
                    throw new FormatException($"Ошибка при парсинге строки: '{line}'. Подробности: {ex.Message}", ex);
                }
            }

            return exportData;
        }

        private string[] SplitCsvLine(string line)
        {
            var pattern = @",(?=(?:[^""]*""[^""]*"")*[^""]*$)(?<!\d)";
            var parts = Regex.Split(line, pattern);
            for (int i = 0; i < parts.Length; i++)
            {
                parts[i] = parts[i].Trim('"');
            }

            List<string> correctedParts = new List<string>();
            for (int i = 0; i < parts.Length; i++)
            {
                if (i + 1 < parts.Length && decimal.TryParse(parts[i] + "," + parts[i + 1], NumberStyles.Any, CultureInfo.GetCultureInfo("ru-RU"), out _))
                {
                    correctedParts.Add(parts[i] + "," + parts[i + 1]);
                    i++;
                }
                else
                {
                    correctedParts.Add(parts[i]);
                }
            }

            return correctedParts.ToArray();
        }

        protected override void ProcessData(CsvData data)
        {
            Console.WriteLine("Обработка данных CSV...");
        }
    }

    public class CsvData
    {
        public List<BankAccount> Accounts { get; set; }
        public List<Category> Categories { get; set; }
        public List<Operation> Operations { get; set; }
    }
}
