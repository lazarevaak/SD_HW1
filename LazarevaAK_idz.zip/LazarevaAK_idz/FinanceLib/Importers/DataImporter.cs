﻿using System;
using System.IO;

namespace FinanceLib.Importers
{
    public abstract class DataImporter<T>
    {
        // Метод для импорта данных из файла
        public void ImportDataFromFile(string filePath)
        {
            if (string.IsNullOrWhiteSpace(filePath))
                throw new ArgumentException("Неверно указан путь к файлу", nameof(filePath));

            try
            {
                string fileContent = File.ReadAllText(filePath);
                T data = ParseData(fileContent);
                ProcessData(data);
            }
            catch (Exception ex)
            {
                throw new Exception("Ошибка при импорте данных: " + ex.Message, ex);
            }
        }

        // Метод для импорта данных из строки
        public void ImportDataFromString(string dataString)
        {
            if (string.IsNullOrWhiteSpace(dataString))
                throw new ArgumentException("Данные пусты", nameof(dataString));

            try
            {
                T data = ParseData(dataString);
                ProcessData(data);
            }
            catch (Exception ex)
            {
                throw new Exception("Ошибка при импорте данных из строки: " + ex.Message, ex);
            }
        }

        // Абстрактные методы для обработки данных
        protected abstract T ParseData(string fileContent);
        protected abstract void ProcessData(T data);
    }
}
