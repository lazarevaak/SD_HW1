﻿using System;
using System.Collections.Generic;
using YamlDotNet.Serialization;
using FinanceLib.DomainModels;

namespace FinanceLib.Importers
{
    public class YamlDataImporter : DataImporter<YamlData>
    {

        public YamlData ImportDataFromFile(string filePath)
        {
            ImportDataFromString(filePath);
            return ParseData(File.ReadAllText(filePath)); // Возвращаем обработанные данные
        }

        // Метод для импорта данных из строки YAML
        public void Import(string rawData)
        {
            ImportDataFromString(rawData); // Импорт из строки
        }

        protected override YamlData ParseData(string fileContent)
        {
            var deserializer = new DeserializerBuilder().Build();
            return deserializer.Deserialize<YamlData>(fileContent);
        }

        protected override void ProcessData(YamlData data)
        {
            Console.WriteLine("Обработка данных YAML...");
        }
    }

    public class YamlData
    {
        public List<BankAccount> Accounts { get; set; }
        public List<Category> Categories { get; set; }
        public List<Operation> Operations { get; set; }
    }
}
