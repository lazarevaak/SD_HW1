﻿using System;
using System.Collections.Generic;
using System.IO;
using FinanceLib.DomainModels;
using FinanceLib.Interfaces;
using FinanceLib.Importers;
using FinanceLib.Exporters;

namespace FinanceLib.Services
{
    public class FinanceManager : IFinanceService
    {
        private readonly Dictionary<Guid, BankAccount> _accounts = new Dictionary<Guid, BankAccount>();
        private readonly Dictionary<Guid, Category> _categories = new Dictionary<Guid, Category>();
        private readonly Dictionary<Guid, Operation> _operations = new Dictionary<Guid, Operation>();

        // Методы работы со счетами
        public IEnumerable<BankAccount> GetBankAccounts() => _accounts.Values;

        public void AddBankAccount(BankAccount account) => _accounts[account.Id] = account;
        public void UpdateBankAccount(BankAccount account) => _accounts[account.Id] = account;
        public void RemoveBankAccount(Guid accountId) => _accounts.Remove(accountId);

        // Методы работы с категориями
        public IEnumerable<Category> GetCategories() => _categories.Values;

        public void AddCategory(Category category) => _categories[category.Id] = category;
        public void UpdateCategory(Category category) => _categories[category.Id] = category;
        public void RemoveCategory(Guid categoryId) => _categories.Remove(categoryId);

        // Методы работы с операциями
        public IEnumerable<Operation> GetOperations() => _operations.Values;

        public void AddOperation(Operation operation) => _operations[operation.Id] = operation;
        public void UpdateOperation(Operation operation) => _operations[operation.Id] = operation;
        public void RemoveOperation(Guid operationId) => _operations.Remove(operationId);

        // Дополнительные методы
        public Dictionary<Guid, decimal> GroupOperationsByCategory(DateTime start, DateTime end)
        {
            return _operations.Values
                .Where(op => op.Date >= start && op.Date <= end)
                .GroupBy(op => op.CategoryId)
                .ToDictionary(g => g.Key, g => g.Sum(op => op.Amount));
        }

        // Экспорт данных
        public void ExportToCsv(string directory)
        {
            var visitor = new CsvExportVisitor();
            foreach (var acc in _accounts.Values)
                acc.Accept(visitor);
            foreach (var cat in _categories.Values)
                cat.Accept(visitor);
            foreach (var op in _operations.Values)
                op.Accept(visitor);

            string result = visitor.GetCsv();
            string filePath = Path.Combine(directory, "export.csv");
            File.WriteAllText(filePath, result);
            Console.WriteLine("Экспорт в CSV завершен.");
        }

        public void ExportToJson(string filePath)
        {
            var visitor = new JsonExportVisitor();
            foreach (var acc in _accounts.Values)
                acc.Accept(visitor);
            foreach (var cat in _categories.Values)
                cat.Accept(visitor);
            foreach (var op in _operations.Values)
                op.Accept(visitor);

            string result = visitor.GetJson();
            File.WriteAllText(filePath, result);
            Console.WriteLine("Экспорт в JSON завершен.");
        }

        public void ExportToYaml(string filePath)
        {
            var visitor = new YamlExportVisitor();
            foreach (var acc in _accounts.Values)
                acc.Accept(visitor);
            foreach (var cat in _categories.Values)
                cat.Accept(visitor);
            foreach (var op in _operations.Values)
                op.Accept(visitor);

            string result = visitor.GetYaml();
            File.WriteAllText(filePath, result);
            Console.WriteLine("Экспорт в YAML завершен.");
        }

        // Импорт данных
        // Импорт данных из строки CSV
        public void ImportFromCsv(string directory)
        {
            string filePath = Path.Combine(directory, "export.csv");
            var importer = new CsvDataImporter();
            CsvData data = importer.ImportDataFromFile(filePath);  // Используем метод для файла и получаем данные
            UpdateCollectionsCsv(data);  // Передаем данные, а не импортера
            Console.WriteLine("Импорт из CSV завершен.");
        }

        // Импорт данных из строки JSON
        public void ImportFromJson(string filePath)
        {
            var importer = new JsonDataImporter();
            JsonData data = importer.ImportDataFromFile(filePath);  // Используем метод для файла и получаем данные
            UpdateCollections(data);  // Передаем данные, а не импортера
            Console.WriteLine("Импорт из JSON завершен.");
        }

        // Импорт данных из строки YAML
        public void ImportFromYaml(string filePath)
        {
            var importer = new YamlDataImporter();
            YamlData data = importer.ImportDataFromFile(filePath);  // Используем метод для файла и получаем данные
            UpdateCollections(data);  // Передаем данные, а не импортера
            Console.WriteLine("Импорт из YAML завершен.");
        }



        // Метод обновления коллекций
        // Метод обновления коллекций для CSV данных
        private void UpdateCollectionsCsv(CsvData data)
        {
            _accounts.Clear();
            _categories.Clear();
            _operations.Clear();

            foreach (var acc in data.Accounts)
                _accounts[acc.Id] = acc;

            foreach (var cat in data.Categories)
                _categories[cat.Id] = cat;

            foreach (var op in data.Operations)
                _operations[op.Id] = op;

            Console.WriteLine("Коллекции обновлены.");
        }

        // Метод обновления коллекций для JSON данных
        private void UpdateCollections(JsonData data)
        {
            _accounts.Clear();
            _categories.Clear();
            _operations.Clear();

            foreach (var acc in data.Accounts)
                _accounts[acc.Id] = acc;

            foreach (var cat in data.Categories)
                _categories[cat.Id] = cat;

            foreach (var op in data.Operations)
                _operations[op.Id] = op;

            Console.WriteLine("Коллекции обновлены.");
        }

        // Метод обновления коллекций для YAML данных
        private void UpdateCollections(YamlData data)
        {
            _accounts.Clear();
            _categories.Clear();
            _operations.Clear();

            foreach (var acc in data.Accounts)
                _accounts[acc.Id] = acc;

            foreach (var cat in data.Categories)
                _categories[cat.Id] = cat;

            foreach (var op in data.Operations)
                _operations[op.Id] = op;

            Console.WriteLine("Коллекции обновлены.");
        }

    }
}
