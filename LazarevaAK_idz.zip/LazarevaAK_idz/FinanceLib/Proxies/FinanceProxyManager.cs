﻿using System;
using System.Collections.Generic;
using System.Linq;
using FinanceLib.DomainModels;
using FinanceLib.Interfaces;

namespace FinanceLib.Proxies
{
    public class FinanceProxyManager : IFinanceService
    {
        private readonly IFinanceService _realService;

        // Кэшированные данные
        private IEnumerable<BankAccount> _cachedBankAccounts;
        private IEnumerable<Category> _cachedCategories;
        private IEnumerable<Operation> _cachedOperations;

        private DateTime _cacheLastUpdated;
        private readonly TimeSpan _cacheExpiration = TimeSpan.FromMinutes(5);

        public FinanceProxyManager(IFinanceService realService)
        {
            _realService = realService ?? throw new ArgumentNullException(nameof(realService));
            RefreshCache();
        }

        // Обновление кэша
        private void RefreshCache()
        {
            Console.WriteLine("Обновление кэша...");
            _cachedBankAccounts = _realService.GetBankAccounts();
            _cachedCategories = _realService.GetCategories();
            _cachedOperations = _realService.GetOperations();
            _cacheLastUpdated = DateTime.Now;
        }

        // Проверка актуальности кэша
        private void EnsureCacheIsValid()
        {
            if ((DateTime.Now - _cacheLastUpdated) > _cacheExpiration)
            {
                RefreshCache();
            }
        }

        // Методы для работы с банковскими счетами
        public IEnumerable<BankAccount> GetBankAccounts()
        {
            EnsureCacheIsValid();
            return _cachedBankAccounts;
        }

        public void AddBankAccount(BankAccount account)
        {
            _realService.AddBankAccount(account);
            RefreshCache();
        }

        public void UpdateBankAccount(BankAccount account)
        {
            _realService.UpdateBankAccount(account);
            RefreshCache();
        }

        public void RemoveBankAccount(Guid accountId)
        {
            _realService.RemoveBankAccount(accountId);
            RefreshCache();
        }

        // Методы для работы с категориями
        public IEnumerable<Category> GetCategories()
        {
            EnsureCacheIsValid();
            return _cachedCategories;
        }

        public void AddCategory(Category category)
        {
            _realService.AddCategory(category);
            RefreshCache();
        }

        public void UpdateCategory(Category category)
        {
            _realService.UpdateCategory(category);
            RefreshCache();
        }

        public void RemoveCategory(Guid categoryId)
        {
            _realService.RemoveCategory(categoryId);
            RefreshCache();
        }

        // Методы для работы с операциями
        public IEnumerable<Operation> GetOperations()
        {
            EnsureCacheIsValid();
            return _cachedOperations;
        }

        public void AddOperation(Operation operation)
        {
            _realService.AddOperation(operation);
            RefreshCache();
        }

        public void UpdateOperation(Operation operation)
        {
            _realService.UpdateOperation(operation);
            RefreshCache();
        }

        public void RemoveOperation(Guid operationId)
        {
            _realService.RemoveOperation(operationId);
            RefreshCache();
        }

        // Дополнительные методы
        public Dictionary<Guid, decimal> GroupOperationsByCategory(DateTime start, DateTime end)
        {
            return _realService.GroupOperationsByCategory(start, end);
        }

        // Экспорт в различные форматы
        public void ExportToCsv(string directory)
        {
            _realService.ExportToCsv(directory);
        }

        public void ExportToJson(string filePath)
        {
            _realService.ExportToJson(filePath);
        }

        public void ExportToYaml(string filePath)
        {
            _realService.ExportToYaml(filePath);
        }

        // Импорт из различных форматов
        public void ImportFromCsv(string directory)
        {
            _realService.ImportFromCsv(directory);
            RefreshCache();
        }

        public void ImportFromJson(string filePath)
        {
            _realService.ImportFromJson(filePath);
            RefreshCache();
        }

        public void ImportFromYaml(string filePath)
        {
            _realService.ImportFromYaml(filePath);
            RefreshCache();
        }

    }
}
