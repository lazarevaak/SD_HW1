﻿using System;
using Microsoft.Extensions.DependencyInjection;
using FinanceLib.Commands;
using FinanceLib.DomainModels;
using FinanceLib.Facades;
using FinanceLib.Factories;
using FinanceLib.Interfaces;
using FinanceLib.Services;

namespace FinanceConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            while (!exit)
            {
                // Настройка DI-контейнера
                var services = new ServiceCollection();

                // Регистрация зависимостей
                services.AddSingleton<IDomainFactory, DomainFactory>();
                services.AddSingleton<IBankAccountFacade, BankAccountFacade>();
                services.AddSingleton<ICategoryFacade, CategoryFacade>();
                services.AddSingleton<IOperationFacade, OperationFacade>();
                // Регистрируем сервис для работы с финансами (бизнес-логика, импорт/экспорт, аналитика)
                services.AddSingleton<IFinanceService, FinanceManager>();

                var serviceProvider = services.BuildServiceProvider();

                // Получение сервисов из контейнера
                var bankAccountFacade = serviceProvider.GetService<IBankAccountFacade>();
                var categoryFacade = serviceProvider.GetService<ICategoryFacade>();
                var operationFacade = serviceProvider.GetService<IOperationFacade>();
                var financeService = serviceProvider.GetService<IFinanceService>();

                
                Console.WriteLine("\n==== Меню Учет Финансов ====");
                Console.WriteLine("1. Создать банковский счет");
                Console.WriteLine("2. Обновить имя банковского счета");
                Console.WriteLine("3. Удалить банковский счет");
                Console.WriteLine("4. Создать категорию");
                Console.WriteLine("5. Обновить категорию");
                Console.WriteLine("6. Удалить категорию");
                Console.WriteLine("7. Создать операцию");
                Console.WriteLine("8. Удалить операцию");
                Console.WriteLine("9. Показать список банковских счетов");
                Console.WriteLine("10. Показать список категорий");
                Console.WriteLine("11. Показать список операций");
                Console.WriteLine("12. Экспорт данных в CSV");
                Console.WriteLine("13. Импорт данных из CSV");
                Console.WriteLine("14. Экспорт данных в JSON");
                Console.WriteLine("15. Импорт данных из JSON");
                Console.WriteLine("16. Экспорт данных в YAML");
                Console.WriteLine("17. Импорт данных из YAML");
                Console.WriteLine("18. Группировка операций по категориям (аналитика)");
                Console.WriteLine("0. Выход");
                Console.Write("Выберите опцию: ");
                var choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            CreateBankAccount(bankAccountFacade);
                            break;
                        case "2":
                            UpdateBankAccountName(bankAccountFacade);
                            break;
                        case "3":
                            DeleteBankAccount(bankAccountFacade);
                            break;
                        case "4":
                            CreateCategory(categoryFacade);
                            break;
                        case "5":
                            UpdateCategory(categoryFacade);
                            break;
                        case "6":
                            DeleteCategory(categoryFacade);
                            break;
                        case "7":
                            CreateOperation(operationFacade, bankAccountFacade, categoryFacade);
                            break;
                        case "8":
                            DeleteOperation(operationFacade);
                            break;
                        case "9":
                            ListBankAccounts(bankAccountFacade);
                            break;
                        case "10":
                            ListCategories(categoryFacade);
                            break;
                        case "11":
                            ListOperations(operationFacade);
                            break;
                        case "12":
                            ExportCSV(financeService);
                            break;
                        case "13":
                            ImportCSV(financeService);
                            break;
                        case "14":
                            ExportJSON(financeService);
                            break;
                        case "15":
                            ImportJSON(financeService);
                            break;
                        case "16":
                            ExportYAML(financeService);
                            break;
                        case "17":
                            ImportYAML(financeService);
                            break;
                        case "18":
                            GroupOperations(financeService);
                            break;
                        case "0":
                            exit = true;
                            Console.WriteLine("Выход из приложения.");
                            break;
                        default:
                            Console.WriteLine("Некорректный выбор. Повторите попытку.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка в основном блоке: {ex.Message}");
                }
            }
        }

        // Метод создания банковского счета
        static void CreateBankAccount(IBankAccountFacade facade)
        {
            try
            {
                Console.Write("Введите название банковского счета: ");
                var name = Console.ReadLine();
                Console.Write("Введите начальный баланс: ");
                if (!decimal.TryParse(Console.ReadLine(), out decimal balance))
                {
                    Console.WriteLine("Некорректное значение баланса.");
                    return;
                }
                ICommand command = new CreateBankAccountCommand(facade, name, balance);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при создании банковского счета: " + ex.Message);
            }
        }

        // Метод обновления имени банковского счета
        static void UpdateBankAccountName(IBankAccountFacade facade)
        {
            try
            {
                ListBankAccounts(facade);
                Console.Write("Введите ID банковского счета для обновления: ");
                if (!Guid.TryParse(Console.ReadLine(), out Guid id))
                {
                    Console.WriteLine("Некорректный ID.");
                    return;
                }
                Console.Write("Введите новое название счета: ");
                var newName = Console.ReadLine();
                ICommand command = new UpdateBankAccountNameCommand(facade, id, newName);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при обновлении банковского счета: " + ex.Message);
            }
        }

        // Метод удаления банковского счета
        static void DeleteBankAccount(IBankAccountFacade facade)
        {
            try
            {
                ListBankAccounts(facade);
                Console.Write("Введите ID банковского счета для удаления: ");
                if (!Guid.TryParse(Console.ReadLine(), out Guid id))
                {
                    Console.WriteLine("Некорректный ID.");
                    return;
                }
                ICommand command = new DeleteBankAccountCommand(facade, id);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при удалении банковского счета: " + ex.Message);
            }
        }

        // Метод создания категории
        static void CreateCategory(ICategoryFacade facade)
        {
            try
            {
                Console.Write("Введите название категории: ");
                var name = Console.ReadLine();
                Console.Write("Введите тип категории (Income/Expense): ");
                var typeStr = Console.ReadLine();
                if (!Enum.TryParse(typeof(CategoryType), typeStr, true, out object type))
                {
                    Console.WriteLine("Некорректный тип категории.");
                    return;
                }
                ICommand command = new CreateCategoryCommand(facade, (CategoryType)type, name);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при создании категории: " + ex.Message);
            }
        }

        // Метод обновления категории
        static void UpdateCategory(ICategoryFacade facade)
        {
            try
            {
                ListCategories(facade);
                Console.Write("Введите ID категории для обновления: ");
                if (!Guid.TryParse(Console.ReadLine(), out Guid id))
                {
                    Console.WriteLine("Некорректный ID.");
                    return;
                }
                Console.Write("Введите новое название категории: ");
                var newName = Console.ReadLine();
                ICommand command = new UpdateCategoryCommand(facade, id, newName);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при обновлении категории: " + ex.Message);
            }
        }

        // Метод удаления категории
        static void DeleteCategory(ICategoryFacade facade)
        {
            try
            {
                ListCategories(facade);
                Console.Write("Введите ID категории для удаления: ");
                if (!Guid.TryParse(Console.ReadLine(), out Guid id))
                {
                    Console.WriteLine("Некорректный ID.");
                    return;
                }
                ICommand command = new DeleteCategoryCommand(facade, id);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при удалении категории: " + ex.Message);
            }
        }

        // Метод создания операции
        static void CreateOperation(IOperationFacade opFacade, IBankAccountFacade accFacade, ICategoryFacade catFacade)
        {
            try
            {
                ListBankAccounts(accFacade);
                Console.Write("Введите ID банковского счета для операции: ");
                if (!Guid.TryParse(Console.ReadLine(), out Guid accountId))
                {
                    Console.WriteLine("Некорректный ID счета.");
                    return;
                }
                ListCategories(catFacade);
                Console.Write("Введите ID категории для операции: ");
                if (!Guid.TryParse(Console.ReadLine(), out Guid categoryId))
                {
                    Console.WriteLine("Некорректный ID категории.");
                    return;
                }
                Console.Write("Введите тип операции (Income/Expense): ");
                var opTypeStr = Console.ReadLine();
                if (!Enum.TryParse(typeof(OperationType), opTypeStr, true, out object opType))
                {
                    Console.WriteLine("Некорректный тип операции.");
                    return;
                }
                Console.Write("Введите сумму операции: ");
                if (!decimal.TryParse(Console.ReadLine(), out decimal amount))
                {
                    Console.WriteLine("Некорректная сумма.");
                    return;
                }
                Console.Write("Введите описание операции (опционально): ");
                var description = Console.ReadLine();
                ICommand command = new CreateOperationCommand(opFacade, (OperationType)opType, accountId, amount, categoryId, description);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при создании операции: " + ex.Message);
            }
        }

        // Метод удаления операции
        static void DeleteOperation(IOperationFacade opFacade)
        {
            try
            {
                ListOperations(opFacade);
                Console.Write("Введите ID операции для удаления: ");
                if (!Guid.TryParse(Console.ReadLine(), out Guid id))
                {
                    Console.WriteLine("Некорректный ID.");
                    return;
                }
                ICommand command = new DeleteOperationCommand(opFacade, id);
                ICommand timedCommand = new TimingCommandDecorator(command);
                timedCommand.Execute();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при удалении операции: " + ex.Message);
            }
        }

        // Метод отображения списка банковских счетов
        static void ListBankAccounts(IBankAccountFacade facade)
        {
            try
            {
                Console.WriteLine("\nСписок банковских счетов:");
                foreach (var account in facade.GetAll())
                {
                    Console.WriteLine($"ID: {account.Id} | Название: {account.Name} | Баланс: {account.Balance}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при выводе списка счетов: " + ex.Message);
            }
        }

        // Метод отображения списка категорий
        static void ListCategories(ICategoryFacade facade)
        {
            try
            {
                Console.WriteLine("\nСписок категорий:");
                foreach (var category in facade.GetAll())
                {
                    Console.WriteLine($"ID: {category.Id} | Название: {category.Name} | Тип: {category.Type}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при выводе списка категорий: " + ex.Message);
            }
        }

        // Метод отображения списка операций
        static void ListOperations(IOperationFacade facade)
        {
            try
            {
                Console.WriteLine("\nСписок операций:");
                foreach (var op in facade.GetAll())
                {
                    Console.WriteLine($"ID: {op.Id} | Тип: {op.Type} | Счет: {op.BankAccountId} | Сумма: {op.Amount} | Дата: {op.Date} | Описание: {op.Description} | Категория: {op.CategoryId}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при выводе списка операций: " + ex.Message);
            }
        }

        // Экспорт в CSV (директория)
        static void ExportCSV(IFinanceService service)
        {
            try
            {
                Console.Write("Введите путь к директории для экспорта CSV: ");
                var directory = Console.ReadLine()?.Trim();
                service.ExportToCsv(directory);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при экспорте в CSV: " + ex.Message);
            }
        }

        // Импорт из CSV (директория с файлом export.csv)
        static void ImportCSV(IFinanceService service)
        {
            try
            {
                Console.Write("Введите путь к директории для импорта CSV (файл export.csv должен быть в этой директории): ");
                var directory = Console.ReadLine()?.Trim();
                service.ImportFromCsv(directory);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при импорте из CSV: " + ex.Message);
            }
        }

        // Экспорт в JSON (файл)
        static void ExportJSON(IFinanceService service)
        {
            try
            {
                Console.Write("Введите путь к файлу для экспорта JSON: ");
                var filePath = Console.ReadLine()?.Trim();
                service.ExportToJson(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при экспорте в JSON: " + ex.Message);
            }
        }

        // Импорт из JSON (файл)
        static void ImportJSON(IFinanceService service)
        {
            try
            {
                Console.Write("Введите путь к файлу для импорта JSON: ");
                var filePath = Console.ReadLine()?.Trim();
                service.ImportFromJson(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при импорте из JSON: " + ex.Message);
            }
        }

        // Экспорт в YAML (файл)
        static void ExportYAML(IFinanceService service)
        {
            try
            {
                Console.Write("Введите путь к файлу для экспорта YAML: ");
                var filePath = Console.ReadLine()?.Trim();
                service.ExportToYaml(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при экспорте в YAML: " + ex.Message);
            }
        }

        // Импорт из YAML (файл)
        static void ImportYAML(IFinanceService service)
        {
            try
            {
                Console.Write("Введите путь к файлу для импорта YAML: ");
                var filePath = Console.ReadLine()?.Trim();
                service.ImportFromYaml(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при импорте из YAML: " + ex.Message);
            }
        }

        // Аналитика: группировка операций по категориям за указанный период
        static void GroupOperations(IFinanceService service)
        {
            try
            {
                Console.Write("Введите начальную дату (формат yyyy-MM-dd): ");
                if (!DateTime.TryParse(Console.ReadLine(), out DateTime start))
                {
                    Console.WriteLine("Неверный формат даты.");
                    return;
                }
                Console.Write("Введите конечную дату (формат yyyy-MM-dd): ");
                if (!DateTime.TryParse(Console.ReadLine(), out DateTime end))
                {
                    Console.WriteLine("Неверный формат даты.");
                    return;
                }
                var groups = service.GroupOperationsByCategory(start, end);
                Console.WriteLine("\nГруппировка операций по категориям:");
                foreach (var group in groups)
                {
                    Console.WriteLine($"Категория ID: {group.Key} | Общая сумма: {group.Value}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка при группировке операций: " + ex.Message);
            }
        }
    }
}
